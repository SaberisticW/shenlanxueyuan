#include <iostream>
#include "AdditionAndSubtractionExercise.h"

using namespace std;

int main()
{
	AdditionAndSubtraction_MainFunc();

	system("pause");

	return 1;
}