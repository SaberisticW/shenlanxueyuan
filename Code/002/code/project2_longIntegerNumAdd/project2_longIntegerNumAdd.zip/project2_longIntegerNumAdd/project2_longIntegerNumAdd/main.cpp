#include <iostream>

#include "LongIntNumAdd.h"

using namespace std;

int main()
{
	LongIntNumAdd_MainFunc();
	system("pause");

	return 1;
}