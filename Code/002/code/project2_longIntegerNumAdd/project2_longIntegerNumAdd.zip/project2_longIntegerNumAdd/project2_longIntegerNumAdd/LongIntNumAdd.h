#pragma once

extern void LongIntNumAdd_MainFunc(void);
